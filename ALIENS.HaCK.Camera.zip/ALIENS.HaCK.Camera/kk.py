# -*- coding: utf -8 -*-
import os
import sys
import fileinput

kamili = raw_input("file? ")
kamili2 = raw_input("Out")
os.system("bash-obfuscate " + kamili + " -o " +kamili2)
prinr("sa7tm")
